<?php

namespace Gamegos\JWS\Exception;

class UnspecifiedAlgorithmException extends JWSException
{
}
