<?php

namespace Gamegos\JWS\Exception;

class InvalidSignatureException extends JWSException
{
}
