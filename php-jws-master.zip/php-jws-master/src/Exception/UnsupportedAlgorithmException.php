<?php

namespace Gamegos\JWS\Exception;

class UnsupportedAlgorithmException extends JWSException
{
}
