<?php

namespace Gamegos\JWS\Exception;

class MalformedSignatureException extends JWSException
{
}
