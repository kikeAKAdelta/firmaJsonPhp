<?php

namespace Gamegos\JWS\Exception;

class UnexpectedAlgorithmException extends JWSException
{
}
