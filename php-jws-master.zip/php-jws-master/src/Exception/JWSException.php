<?php

namespace Gamegos\JWS\Exception;

class JWSException extends \RuntimeException
{
}
